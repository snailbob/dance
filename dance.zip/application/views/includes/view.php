<?php

	$this->load->view('includes/header');
	$this->load->view('front/'.$view);
	$this->load->view('includes/footer');

?>